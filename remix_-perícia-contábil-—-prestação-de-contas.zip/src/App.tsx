/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import { 
  BarChart3, 
  FileText, 
  Search, 
  Calculator, 
  ClipboardCheck, 
  Scale, 
  Building2, 
  UserCircle,
  Plus,
  LayoutDashboard,
  CheckCircle2,
  AlertCircle,
  Clock,
  ArrowUpRight,
  ArrowDownLeft,
  ChevronRight,
  ChevronDown,
  ExternalLink,
  Upload,
  Paperclip,
  Download,
  Eye,
  CheckSquare,
  Square,
  X,
  MoreHorizontal,
  Ban,
  FileUp,
  ListChecks,
  ShieldCheck,
  ShieldAlert,
  Info,
  History
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip as RechartsTooltip, 
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell
} from 'recharts';
import { cn, formatCurrency } from './lib/utils';
import { LEGAL_BASES, WORKFLOW_STEPS, CATEGORY_REQUIREMENTS } from './constants';
import { Case, Transaction, CaseSphere, ChecklistItem } from './types';

// Mock Data
const MOCK_CASES: Case[] = [
  {
    id: '0703620-96.2022.8.07.0014',
    title: 'Espólio de Maria Dantas da Costa × Getúlio de Oliveira Filho',
    sphere: 'JUDICIAL',
    nature: 'Exigir Contas (Art. 550 CPC)',
    responsible: 'Getúlio de Oliveira Filho (Curador)',
    period: { start: '2017-08-24', end: '2019-03-01' },
    currentPhase: 'ANALYSIS',
    initialBalance: 120559.90,
    finalBalance: 0,
    notes: 'Período: 24/08/2017 a 01/03/2019. Foco em transferência de R$ 60k e honorários de R$ 10k.',
    transactions: [
      { 
        id: 'real-t1', 
        date: '2019-01-21', 
        description: 'Transferência p/ Conta Pessoal do Curador', 
        type: 'OUTFLOW', 
        value: 60279.95, 
        category: 'Transferência', 
        status: 'PENDING', 
        hasDocument: true, 
        documentRef: 'Extrato_BB_Jan19.pdf',
        legalBasis: 'CPC Art. 550',
        peritialNotes: 'Indício de apropriação indevida dias antes do óbito. Necessária prova de proveito para Maria Dantas.'
      },
      { 
        id: 'real-t2', 
        date: '2017-09-10', 
        description: 'Honorários Advocatícios - Unimed Manaus', 
        type: 'OUTFLOW', 
        value: 10000.00, 
        category: 'Jurídico', 
        status: 'PENDING', 
        hasDocument: true,
        documentRef: 'Contrato_Honorarios_Unimed.pdf',
        legalBasis: 'CC Art. 1.781',
        checklist: [
          { id: 'h1', label: 'Contrato Assinado', status: 'VALIDATED', required: true },
          { id: 'h2', label: 'Prova de Atuação (Processo)', status: 'MISSING', required: true }
        ]
      },
      { 
        id: 'real-t3', 
        date: '2018-05-15', 
        description: 'Plano de Saúde (José Augusto) - Acordo', 
        type: 'OUTFLOW', 
        value: 9300.00, 
        category: 'Saúde', 
        status: 'ACCEPTED', 
        hasDocument: true,
        isAgreedDeduction: true,
        legalBasis: 'Acordo entre Partes (ID 267117844)'
      },
      { 
        id: 'real-t4', 
        date: '2018-11-20', 
        description: 'Abastecimento Veículo (Posto Shell)', 
        type: 'OUTFLOW', 
        value: 250.00, 
        category: 'Manutenção', 
        status: 'GLOSSED', 
        hasDocument: true,
        glosaReason: 'Despesa pessoal/terceiros. Veículo não pertence à curatelada.',
        peritialNotes: 'Reincidência de gastos com transporte sem prova de deslocamento da interdita.'
      },
      { 
        id: 'real-t5', 
        date: '2019-02-26', 
        description: 'Compra de Sofá 3 Lugares', 
        type: 'OUTFLOW', 
        value: 1029.00, 
        category: 'Suprimentos', 
        status: 'GLOSSED', 
        hasDocument: true,
        glosaReason: 'Curatelada internada em UTI. Sem benefício demonstrado.',
        documentRef: 'NF_Sofa_2602.pdf'
      },
      { 
        id: 'real-t6', 
        date: '2018-08-12', 
        description: 'Medicamentos Drogaria X (Diligência)', 
        type: 'OUTFLOW', 
        value: 450.00, 
        category: 'Saúde', 
        status: 'PENDING', 
        hasDocument: true,
        isIllegible: true,
        requiresDiligence: true,
        diligenceDescription: 'Nota fiscal ilegível. Requerer reapresentação ou consulta ao portal da NF-e.',
        legalBasis: 'CPC Art. 473'
      },
      { 
        id: 'real-t7', 
        date: '2017-08-25', 
        description: 'Saldo Inicial Conta BB', 
        type: 'INFLOW', 
        value: 120559.90, 
        category: 'Receita', 
        status: 'ACCEPTED', 
        hasDocument: true,
        legalBasis: 'Saldo de Abertura'
      }
    ]
  }
];

export default function App() {
  const [cases, setCases] = useState<Case[]>(MOCK_CASES);
  const [activeSphere, setActiveSphere] = useState<CaseSphere>('JUDICIAL');
  const [selectedCaseId, setSelectedCaseId] = useState<string>('0703620-96.2022.8.07.0014');
  const [expandedTransactionId, setExpandedTransactionId] = useState<string | null>(null);
  const [selectedTransactionIds, setSelectedTransactionIds] = useState<string[]>([]);
  const [showBulkDropdown, setShowBulkDropdown] = useState(false);
  const [draggingId, setDraggingId] = useState<string | null>(null);
  const [uploadingTransactionId, setUploadingTransactionId] = useState<string | null>(null);
  const [previewTransactionId, setPreviewTransactionId] = useState<string | null>(null);
  const [legalSearchQuery, setLegalSearchQuery] = useState('');
  const [activeTab, setActiveTab] = useState<'DASHBOARD' | 'TRANSACTIONS' | 'RECONCILIATION' | 'REPORT'>('DASHBOARD');
  const [showCalculator, setShowCalculator] = useState(false);

  const currentCase = cases.find(c => c.id === selectedCaseId) || cases[0];

  const getInitialChecklist = (category: string): ChecklistItem[] => {
    const requirements = CATEGORY_REQUIREMENTS[category] || CATEGORY_REQUIREMENTS['DEFAULT'];
    return requirements.map((req, idx) => ({
      id: `req-${idx}-${Math.random().toString(36).substr(2, 9)}`,
      label: req,
      status: 'PENDING',
      required: true
    }));
  };

  const validateDocument = (checklist: ChecklistItem[]): ChecklistItem[] => {
    return checklist.map(item => {
      const random = Math.random();
      if (random > 0.3) {
        return { ...item, status: 'VALIDATED' };
      }
      return { ...item, status: 'MISSING' };
    });
  };

  const filteredCases = useMemo(() => {
    return cases.filter(c => c.sphere === activeSphere);
  }, [activeSphere, cases]);

  const handleFileUpload = (transactionId: string, event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setCases(prevCases => prevCases.map(c => {
      if (c.id === selectedCaseId) {
        return {
          ...c,
          transactions: c.transactions.map(t => {
            if (t.id === transactionId) {
              const baseChecklist = t.checklist && t.checklist.length > 0 ? t.checklist : getInitialChecklist(t.category);
              const validatedChecklist = validateDocument(baseChecklist);
              return {
                ...t,
                hasDocument: true,
                documentRef: file.name,
                checklist: validatedChecklist
              };
            }
            return t;
          })
        };
      }
      return c;
    }));
  };

  const handlePeritialNotesChange = (transactionId: string, notes: string) => {
    setCases(prevCases => prevCases.map(c => {
      if (c.id === selectedCaseId) {
        return {
          ...c,
          transactions: c.transactions.map(t => {
            if (t.id === transactionId) {
              return {
                ...t,
                peritialNotes: notes
              };
            }
            return t;
          })
        };
      }
      return c;
    }));
  };

  const handleGeneralNotesChange = (transactionId: string, notes: string) => {
    setCases(prevCases => prevCases.map(c => {
      if (c.id === selectedCaseId) {
        return {
          ...c,
          transactions: c.transactions.map(t => {
            if (t.id === transactionId) {
              return {
                ...t,
                generalNotes: notes
              };
            }
            return t;
          })
        };
      }
      return c;
    }));
  };

  const handleBulkStatusChange = (status: Transaction['status']) => {
    setCases(prevCases => prevCases.map(c => {
      if (c.id === selectedCaseId) {
        return {
          ...c,
          transactions: c.transactions.map(t => {
            if (selectedTransactionIds.includes(t.id)) {
              return { 
                ...t, 
                status,
                glosaReason: status === 'GLOSSED' ? t.glosaReason || 'Item glosado por pendência documental/técnica.' : t.glosaReason
              };
            }
            return t;
          })
        };
      }
      return c;
    }));
    setSelectedTransactionIds([]);
    setShowBulkDropdown(false);
  };

  const handleGlosaReasonChange = (transactionId: string, reason: string) => {
    setCases(prevCases => prevCases.map(c => {
      if (c.id === selectedCaseId) {
        return {
          ...c,
          transactions: c.transactions.map(t => {
            if (t.id === transactionId) {
              return {
                ...t,
                glosaReason: reason
              };
            }
            return t;
          })
        };
      }
      return c;
    }));
  };

  const handleGlosaNotesChange = (transactionId: string, notes: string) => {
    setCases(prevCases => prevCases.map(c => {
      if (c.id === selectedCaseId) {
        return {
          ...c,
          transactions: c.transactions.map(t => {
            if (t.id === transactionId) {
              return {
                ...t,
                glosaNotes: notes
              };
            }
            return t;
          })
        };
      }
      return c;
    }));
  };

  const handleLegalBasisChange = (transactionId: string, basis: string) => {
    setCases(prevCases => prevCases.map(c => {
      if (c.id === selectedCaseId) {
        return {
          ...c,
          transactions: c.transactions.map(t => {
            if (t.id === transactionId) {
              return {
                ...t,
                legalBasis: basis
              };
            }
            return t;
          })
        };
      }
      return c;
    }));
  };

  const toggleSelectAll = () => {
    if (selectedTransactionIds.length === currentCase.transactions.length) {
      setSelectedTransactionIds([]);
    } else {
      setSelectedTransactionIds(currentCase.transactions.map(t => t.id));
    }
  };

  const toggleSelectTransaction = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (selectedTransactionIds.includes(id)) {
      setSelectedTransactionIds(prev => prev.filter(tid => tid !== id));
    } else {
      setSelectedTransactionIds(prev => [...prev, id]);
    }
  };

  const onDragOver = (e: React.DragEvent, id: string) => {
    e.preventDefault();
    setDraggingId(id);
  };

  const onDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setDraggingId(null);
  };

  const onDrop = (e: React.DragEvent, id: string) => {
    e.preventDefault();
    setDraggingId(null);
    const files = e.dataTransfer.files;
    if (files && files.length > 0) {
      handleFileUpload(id, { target: { files } } as any);
    }
  };

  return (
    <div className="flex h-screen bg-[#0A0C10] font-sans text-[#E0E0E0] overflow-hidden selection:bg-amber-500/30">
      {/* Modals */}
      <AnimatePresence>
        {previewTransactionId && (
          <div className="fixed inset-0 z-[110] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setPreviewTransactionId(null)}
              className="absolute inset-0 bg-black/95 backdrop-blur-2xl"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, y: 30 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 30 }}
              className="relative w-full max-w-5xl h-[85vh] bg-[#0A0C10] border border-white/10 rounded-3xl overflow-hidden shadow-2xl flex flex-col"
            >
              <div className="p-6 border-b border-white/5 bg-[#161920] flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 rounded-xl bg-amber-500/10 flex items-center justify-center text-amber-500 border border-amber-500/20">
                    <FileText className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-black text-sm uppercase tracking-widest text-white italic">
                      {currentCase.transactions.find(t => t.id === previewTransactionId)?.documentRef || 'Documento de Suporte'}
                    </h3>
                    <p className="text-[9px] text-white/30 uppercase tracking-[0.2em] font-bold mt-1">Vínculo: {currentCase.transactions.find(t => t.id === previewTransactionId)?.description}</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <button 
                    onClick={() => alert('Download do documento forense iniciado.')}
                    className="p-2 bg-white/5 hover:bg-white/10 rounded-lg text-white/40 hover:text-white transition-all"
                  >
                    <Download className="w-4 h-4" />
                  </button>
                  <button 
                    onClick={() => setPreviewTransactionId(null)}
                    className="p-2 bg-white/5 hover:bg-red-500/10 rounded-lg text-white/40 hover:text-red-500 transition-all font-black"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              </div>

              <div className="flex-1 overflow-auto p-12 bg-[#0A0C10] relative group">
                <div className="max-w-2xl mx-auto bg-white shadow-[0_0_100px_rgba(0,0,0,1)] min-h-[1000px] p-20 relative overflow-hidden">
                  <div className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-[0.03] rotate-[-45deg] select-none">
                    <span className="text-8xl font-black uppercase tracking-[0.2em]">CÓPIA FORENSE</span>
                  </div>

                  <div className="flex justify-between items-start mb-20 border-b-2 border-black pb-8">
                     <div className="text-black space-y-1">
                       <p className="text-[10px] font-black uppercase tracking-widest">Digitalização Peritial</p>
                       <p className="text-[8px] opacity-60">ID: {previewTransactionId}</p>
                     </div>
                     <div className="text-right text-black space-y-1">
                        <p className="text-[12px] font-black uppercase tracking-widest">{currentCase.sphere}</p>
                        <p className="text-[8px] opacity-60">Autenticado em: {new Date().toLocaleDateString('pt-BR')}</p>
                     </div>
                  </div>

                  <div className="space-y-6">
                     <div className="h-8 bg-black/5 rounded w-3/4" />
                     <div className="h-4 bg-black/5 rounded w-full" />
                     <div className="h-4 bg-black/5 rounded w-full opacity-50" />
                     <div className="h-32 bg-black/5 rounded w-full animate-pulse border-2 border-dashed border-black/10 flex items-center justify-center">
                        <span className="text-[10px] uppercase font-black tracking-widest text-black/20">Conteúdo do Documento Protegido</span>
                     </div>
                     <div className="grid grid-cols-2 gap-8 pt-12">
                        <div className="space-y-4">
                          <div className="h-4 bg-black/5 rounded w-full" />
                          <div className="h-4 bg-black/5 rounded w-5/6" />
                        </div>
                        <div className="space-y-4">
                          <div className="h-4 bg-black/5 rounded w-full opacity-30" />
                          <div className="h-4 bg-black/5 rounded w-2/3 opacity-20" />
                        </div>
                     </div>
                  </div>

                  <div className="absolute bottom-20 right-20 w-32 h-32 border-4 border-amber-600/30 rounded-full flex items-center justify-center rotate-12 flex-col text-amber-600/40">
                     <span className="text-[8px] font-black uppercase tracking-widest">CONFERE COM O</span>
                     <span className="text-[10px] font-black uppercase tracking-widest">ORIGINAL</span>
                     <div className="w-12 h-[1px] bg-amber-600/20 my-1" />
                     <span className="text-[6px] font-black uppercase tracking-widest">PERITO JUDICIAL</span>
                  </div>
                </div>
              </div>

              <div className="p-4 bg-[#161920] border-t border-white/5 flex items-center justify-center gap-8 text-[9px] uppercase tracking-widest font-black text-white/20">
                <span className="flex items-center gap-2"><div className="w-1.5 h-1.5 bg-green-500 rounded-full" /> SHA-256 Verificado</span>
                <span className="flex items-center gap-2"><div className="w-1.5 h-1.5 bg-amber-500 rounded-full" /> Assinatura Digital Ativa</span>
                <span className="flex items-center gap-2"><div className="w-1.5 h-1.5 bg-blue-500 rounded-full" /> Metadados Integrados</span>
              </div>
            </motion.div>
          </div>
        )}

        {uploadingTransactionId && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setUploadingTransactionId(null)}
              className="absolute inset-0 bg-black/90 backdrop-blur-md"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="relative w-full max-w-lg bg-[#0F1117] border border-white/10 rounded-3xl overflow-hidden shadow-2xl"
            >
              <div className="p-8 border-b border-white/5 bg-[#161920] flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-2xl bg-amber-500/10 flex items-center justify-center text-amber-500 border border-amber-500/20">
                    <FileUp className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="font-black text-lg uppercase tracking-widest text-white italic">Anexar Suporte</h3>
                    <p className="text-[10px] text-white/30 uppercase tracking-[0.2em] font-bold mt-1">Evidência Documental Forense</p>
                  </div>
                </div>
                <button 
                  onClick={() => setUploadingTransactionId(null)}
                  className="text-white/20 hover:text-white transition-colors"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>

              <div className="p-10 space-y-8">
                <div className="space-y-4">
                  <div className="bg-[#0A0C10]/50 p-6 rounded-2xl border border-white/5 space-y-3 relative overflow-hidden group/target">
                    <div className="absolute top-0 right-0 w-24 h-24 bg-amber-500/5 blur-3xl -mr-12 -mt-12 group-hover/target:bg-amber-500/10 transition-colors" />
                    <span className="text-[9px] uppercase tracking-widest font-black text-amber-500/60 flex items-center gap-2">
                       <div className="w-1 h-1 rounded-full bg-amber-500 animate-pulse" />
                       Transação Alvo
                    </span>
                    <h4 className="text-sm font-bold text-white uppercase tracking-tight truncate relative z-10">
                      {currentCase.transactions.find(t => t.id === uploadingTransactionId)?.description}
                    </h4>
                    <div className="flex items-center justify-between mt-4 border-t border-white/5 pt-4">
                      <div className="flex flex-col">
                        <span className="text-[9px] text-white/10 uppercase font-black">Data da Operação</span>
                        <span className="text-[10px] text-white/40 uppercase font-bold tracking-widest">{currentCase.transactions.find(t => t.id === uploadingTransactionId)?.date}</span>
                      </div>
                      <div className="flex flex-col items-end">
                        <span className="text-[9px] text-white/10 uppercase font-black">Montante</span>
                        <span className="text-xs font-mono font-black text-amber-500 tracking-tighter">{formatCurrency(currentCase.transactions.find(t => t.id === uploadingTransactionId)?.value || 0)}</span>
                      </div>
                    </div>
                  </div>

                  <div 
                    onDragOver={(e) => onDragOver(e, uploadingTransactionId!)}
                    onDragLeave={onDragLeave}
                    onDrop={(e) => {
                      onDrop(e, uploadingTransactionId!);
                      setUploadingTransactionId(null);
                    }}
                    className={cn(
                      "relative border-2 border-dashed rounded-3xl p-16 transition-all duration-500 flex flex-col items-center justify-center gap-6 group cursor-pointer overflow-hidden",
                      draggingId === uploadingTransactionId
                        ? "border-amber-500 bg-amber-500/10 scale-[1.02] shadow-2xl shadow-amber-500/5"
                        : "border-white/5 bg-[#0A0C10] hover:border-white/20 hover:bg-white/[0.02]"
                    )}
                  >
                    <div className={cn(
                      "w-20 h-20 rounded-full flex items-center justify-center transition-all duration-500 relative",
                      draggingId === uploadingTransactionId 
                        ? "bg-amber-500 text-black shadow-2xl shadow-amber-500/50 scale-110" 
                        : "bg-white/5 text-white/10 group-hover:bg-amber-500/10 group-hover:text-amber-500 group-hover:scale-105"
                    )}>
                      <Upload className="w-8 h-8" />
                      {draggingId === uploadingTransactionId && (
                        <div className="absolute inset-0 rounded-full border-2 border-amber-500 animate-ping opacity-40" />
                      )}
                    </div>
                    <div className="text-center relative z-10">
                      <p className="text-xs font-black uppercase tracking-[0.3em] text-white/80 group-hover:text-white transition-colors">Arraste a evidência aqui</p>
                      <p className="text-[10px] text-white/20 mt-3 uppercase font-black font-serif tracking-[0.2em] italic group-hover:text-white/40 transition-colors">Digitalização de alta fidelidade recomendada</p>
                    </div>

                    {/* Decorative elements for drag state */}
                    {draggingId === uploadingTransactionId && (
                      <div className="absolute inset-0 bg-gradient-to-t from-amber-500/5 to-transparent pointer-events-none" />
                    )}

                    <input 
                      type="file" 
                      className="absolute inset-0 opacity-0 cursor-pointer"
                      onChange={(e) => {
                        handleFileUpload(uploadingTransactionId!, e);
                        setUploadingTransactionId(null);
                      }}
                    />
                  </div>
                </div>

                <div className="flex gap-4">
                  <button 
                    onClick={() => setUploadingTransactionId(null)}
                    className="flex-1 bg-[#0A0C10] border border-white/5 px-6 py-4 rounded-xl text-[10px] font-black uppercase tracking-widest text-white/30 hover:text-white hover:bg-white/5 transition-all"
                  >
                    Cancelar
                  </button>
                  <label className="flex-1">
                    <div className="w-full bg-amber-500 text-black px-6 py-4 rounded-xl text-[10px] font-black uppercase tracking-widest text-center cursor-pointer hover:bg-amber-400 transition-all shadow-lg shadow-amber-500/20">
                      Confirmar Anexo
                    </div>
                    <input 
                      type="file" 
                      className="hidden" 
                      onChange={(e) => {
                        handleFileUpload(uploadingTransactionId!, e);
                        setUploadingTransactionId(null);
                      }}
                    />
                  </label>
                </div>
              </div>
            </motion.div>
          </div>
        )}

        {showCalculator && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowCalculator(false)}
              className="absolute inset-0 bg-black/80 backdrop-blur-md"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="relative bg-[#0F1117] border border-white/10 w-full max-w-lg rounded-2xl shadow-2xl overflow-hidden"
            >
              <div className="bg-[#161920] p-6 text-white border-b border-white/5 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Calculator className="w-6 h-6 text-amber-500" />
                  <h3 className="text-xl font-bold uppercase tracking-tight">Atualização Monetária</h3>
                </div>
                <button onClick={() => setShowCalculator(false)} className="text-white/40 hover:text-white">&times;</button>
              </div>
              <div className="p-8 space-y-6">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-[10px] uppercase font-bold text-white/30 tracking-widest">Valor Principal</label>
                    <input type="number" defaultValue={50000} className="w-full bg-[#161920] border border-white/5 rounded-lg px-4 py-3 font-mono text-amber-500 outline-none focus:border-amber-500/50 transition-all" />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] uppercase font-bold text-white/30 tracking-widest">Índice</label>
                    <select className="w-full bg-[#161920] border border-white/5 rounded-lg px-4 py-3 text-sm text-white/80 outline-none focus:border-amber-500/50">
                      <option>IPCA-E (IBGE)</option>
                      <option>SELIC (Bacen)</option>
                      <option>IGP-M (FGV)</option>
                    </select>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-[10px] uppercase font-bold text-white/30 tracking-widest">Data Base</label>
                    <input type="date" className="w-full bg-[#161920] border border-white/5 rounded-lg px-4 py-3 text-sm text-white/80 outline-none focus:border-amber-500/50" />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] uppercase font-bold text-white/30 tracking-widest">Juros Mora</label>
                    <div className="relative">
                      <input type="number" defaultValue={1} className="w-full bg-[#161920] border border-white/5 rounded-lg px-4 py-3 pr-12 text-sm text-white/80 outline-none focus:border-amber-500/50" />
                      <span className="absolute right-4 top-1/2 -translate-y-1/2 text-white/20 text-[10px] font-bold uppercase tracking-widest">% a.m</span>
                    </div>
                  </div>
                </div>
                <div className="pt-6 border-t border-white/5">
                  <div className="flex justify-between items-center mb-6">
                    <span className="text-xs uppercase tracking-widest text-white/40">Valor Atualizado</span>
                    <span className="text-3xl font-bold font-mono text-amber-500 tracking-tighter">{formatCurrency(58432.12)}</span>
                  </div>
                  <button className="w-full bg-amber-500 text-black py-4 rounded-xl font-bold hover:bg-amber-400 transition-all flex items-center justify-center gap-2 shadow-lg shadow-amber-500/10">
                    <BarChart3 className="w-4 h-4" />
                    GERAR MEMÓRIA DE CÁLCULO
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Sidebar */}
      <aside className="w-64 bg-[#0F1117] text-white flex flex-col border-r border-white/5">
        <div className="p-8 border-b border-white/5">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-8 h-8 bg-amber-500 rounded flex items-center justify-center text-black font-bold text-lg shadow-lg shadow-amber-500/20">Σ</div>
            <span className="text-lg font-semibold tracking-tight uppercase">Skill <span className="text-amber-500">Pericial</span></span>
          </div>
          <p className="text-[9px] uppercase tracking-[0.3em] text-white/20 font-bold">Forensic Excellence System</p>
        </div>

        <nav className="flex-1 p-6 space-y-10 overflow-y-auto">
          <div>
            <p className="text-[10px] uppercase tracking-[0.2em] text-white/20 mb-6 font-bold">Esferas Ativas</p>
            <div className="space-y-1.5">
              <SphereItem 
                icon={<Scale className="w-4 h-4" />} 
                label="Judicial" 
                active={activeSphere === 'JUDICIAL'} 
                onClick={() => { setActiveSphere('JUDICIAL'); setSelectedCaseId('c3'); }} 
              />
              <SphereItem 
                icon={<Building2 className="w-4 h-4" />} 
                label="Administrativa" 
                active={activeSphere === 'ADMINISTRATIVE'} 
                onClick={() => { setActiveSphere('ADMINISTRATIVE'); setSelectedCaseId('c2'); }} 
              />
              <SphereItem 
                icon={<UserCircle className="w-4 h-4" />} 
                label="Privada" 
                active={activeSphere === 'PRIVATE'} 
                onClick={() => { setActiveSphere('PRIVATE'); setSelectedCaseId('c1'); }} 
              />
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between px-2 mb-6">
              <p className="text-[10px] uppercase tracking-[0.2em] text-white/20 font-bold">Meus Casos</p>
              <button className="text-white/20 hover:text-amber-500 transition-colors">
                <Plus className="w-3 h-3" />
              </button>
            </div>
            <div className="space-y-3">
              {filteredCases.map(c => (
                <button 
                  key={c.id}
                  onClick={() => setSelectedCaseId(c.id)}
                  className={cn(
                    "w-full text-left p-3 rounded-lg border transition-all flex flex-col gap-1.5",
                    selectedCaseId === c.id 
                      ? "bg-amber-500/10 border-amber-500/30 text-white" 
                      : "bg-[#161920]/40 border-white/5 text-white/40 hover:bg-white/5"
                  )}
                >
                  <span className={cn("truncate block font-medium text-xs", selectedCaseId === c.id ? "text-amber-500" : "text-white/60")}>{c.title}</span>
                  <div className="flex items-center gap-2">
                    <span className="text-[8px] opacity-40 uppercase tracking-widest font-bold">{c.nature}</span>
                  </div>
                </button>
              ))}
              {filteredCases.length === 0 && (
                <div className="px-3 py-6 text-center border border-dashed border-white/5 rounded-xl">
                  <p className="text-[9px] text-white/10 uppercase font-black tracking-widest italic">Vazio</p>
                </div>
              )}
            </div>
          </div>
        </nav>

        <div className="p-6 border-t border-white/5">
          <div className="bg-[#161920] border border-white/5 rounded-xl p-4 flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-amber-500 flex items-center justify-center text-xs font-bold text-black shrink-0 shadow-lg shadow-amber-500/10">
              TP
            </div>
            <div className="overflow-hidden">
              <p className="text-[10px] font-bold uppercase tracking-widest truncate">Perito Master</p>
              <p className="text-[9px] text-amber-500/60 font-mono tracking-tighter truncate leading-none mt-1">SESSÃO: 2024_A01</p>
            </div>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <header className="h-20 bg-[#0F1117] border-b border-white/5 flex items-center justify-between px-10">
          <div className="flex items-center gap-6">
             <div>
                <h1 className="text-[10px] font-black uppercase tracking-[0.4em] text-white/20 mb-1.5">Unidade de Processamento</h1>
                <div className="flex items-center gap-3">
                  <span className="text-xl font-bold tracking-tight text-white">{currentCase.title}</span>
                  <div className="px-2 py-0.5 bg-amber-500/10 border border-amber-500/20 rounded text-[9px] font-black text-amber-500 uppercase tracking-widest">
                    {currentCase.nature}
                  </div>
                </div>
             </div>
          </div>

          <div className="flex items-center gap-8">
            <div className="flex bg-[#161920] border border-white/5 p-1 rounded-lg">
              <TabButton active={activeTab === 'DASHBOARD'} onClick={() => setActiveTab('DASHBOARD')} icon={<LayoutDashboard className="w-4 h-4" />} label="Dashboard" />
              <TabButton active={activeTab === 'TRANSACTIONS'} onClick={() => setActiveTab('TRANSACTIONS')} icon={<ClipboardCheck className="w-4 h-4" />} label="Análise" />
              <TabButton active={activeTab === 'RECONCILIATION'} onClick={() => setActiveTab('RECONCILIATION')} icon={<BarChart3 className="w-4 h-4" />} label="Conciliação" />
              <TabButton active={activeTab === 'REPORT'} onClick={() => setActiveTab('REPORT')} icon={<FileText className="w-4 h-4" />} label="Emissão" />
            </div>
            <div className="h-8 w-px bg-white/5" />
            <button 
              onClick={() => setShowCalculator(true)}
              className="bg-amber-500 text-black px-5 py-2.5 rounded-lg text-xs font-black uppercase tracking-widest hover:bg-amber-400 transition-all flex items-center gap-2 shadow-lg shadow-amber-500/10"
            >
              <Calculator className="w-4 h-4" />
              <span>Calculadora</span>
            </button>
          </div>
        </header>

        {/* Scrollable Area */}
        <div className="flex-1 overflow-y-auto p-10 bg-[#0A0C10]">
          <AnimatePresence mode="wait">
            {activeTab === 'DASHBOARD' && (
              <motion.div 
                key="dashboard"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="space-y-12"
              >
                {/* Workflow Steps (Design HTML Style) */}
                <div className="flex justify-between items-center bg-[#0F1117] border border-white/5 p-8 rounded-2xl relative overflow-hidden">
                  <div className="absolute top-0 right-0 w-32 h-32 bg-amber-500/5 blur-3xl pointer-events-none" />
                  <div className="flex gap-12">
                    {WORKFLOW_STEPS.map((step, idx) => {
                      const status = getPhaseStatus(step.id as any, currentCase.currentPhase);
                      return (
                        <div key={step.id} className="flex gap-4 items-center">
                          <div className={cn(
                            "w-8 h-8 rounded-full border flex items-center justify-center text-[11px] font-black transition-all",
                            status === 'active' ? "border-amber-500 text-black bg-amber-500 shadow-lg shadow-amber-500/20" : 
                            status === 'completed' ? "border-amber-500/30 text-amber-500 bg-amber-500/5" : "border-white/10 text-white/20"
                          )}>
                            {idx + 1}
                          </div>
                          <div className="flex flex-col">
                            <span className={cn(
                              "text-[10px] uppercase tracking-widest font-bold",
                              status === 'active' ? "text-amber-500" : status === 'completed' ? "text-amber-500/60" : "text-white/10"
                            )}>{step.label}</span>
                            <span className="text-[9px] text-white/20 font-mono tracking-tighter mt-0.5">{step.id}</span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                  <div className="px-5 py-2 border border-white/10 rounded-lg bg-white/5">
                    <span className="text-[10px] uppercase tracking-widest font-black text-white/40">Status: Perito Ativo</span>
                  </div>
                </div>

                {/* Top KPI Row */}
                <div className="grid grid-cols-4 gap-6">
                  <StatCard 
                    label="Receita Total" 
                    value={formatCurrency(currentCase.transactions.filter(t => t.type === 'INFLOW' && t.status === 'ACCEPTED').reduce((acc, t) => acc + t.value, 0))}
                    icon={<ArrowUpRight className="text-white/20" />}
                  />
                  <StatCard 
                    label="Despesas Aceitas" 
                    value={formatCurrency(currentCase.transactions.filter(t => t.type === 'OUTFLOW' && t.status === 'ACCEPTED').reduce((acc, t) => acc + t.value, 0))}
                    icon={<ArrowDownLeft className="text-white/20" />}
                  />
                  <StatCard 
                    label="Glosas Periciais" 
                    value={formatCurrency(currentCase.transactions.filter(t => t.status === 'GLOSSED').reduce((acc, t) => acc + t.value, 0))}
                    icon={<AlertCircle className="text-red-500/40" />}
                    variant="danger"
                  />
                  <StatCard 
                    label="Saldo Apurado" 
                    value={formatCurrency(calculateSaldo(currentCase))}
                    icon={<Scale className="text-amber-500" />}
                    variant="highlight"
                  />
                </div>

                <div className="grid grid-cols-3 gap-10">
                  <div className="col-span-2 bg-[#161920] border border-white/5 rounded-2xl p-8 space-y-8">
                    <div className="flex items-center justify-between border-b border-white/5 pb-6">
                      <h2 className="font-bold text-sm uppercase tracking-widest flex items-center gap-3">
                        <BarChart3 className="w-4 h-4 text-amber-500" />
                        Fluxo de Caixa Analítico
                      </h2>
                      <div className="text-[10px] text-white/30 font-mono uppercase tracking-widest">Base de Dados: {currentCase.period.start} - {currentCase.period.end}</div>
                    </div>
                    <div className="h-[340px] w-full">
                       <ResponsiveContainer width="100%" height="100%">
                         <BarChart data={prepareBarChartData(currentCase)}>
                           <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="rgba(255,255,255,0.03)" />
                           <XAxis dataKey="name" fontSize={10} tickLine={false} axisLine={false} tick={{ fill: 'rgba(255,255,255,0.3)' }} />
                           <YAxis fontSize={10} tickLine={false} axisLine={false} tickFormatter={(val) => `R$ ${val/1000}k`} tick={{ fill: 'rgba(255,255,255,0.3)' }} />
                           <RechartsTooltip 
                             contentStyle={{ backgroundColor: '#0F1117', borderRadius: '12px', border: '1px solid rgba(255,255,255,0.05)', boxShadow: '0 20px 25px -5px rgb(0 0 0 / 0.5)' }}
                             formatter={(val: number) => [formatCurrency(val), 'Valor']}
                             labelStyle={{ color: 'rgba(255,255,255,0.4)', textTransform: 'uppercase', fontSize: '10px', marginBottom: '8px' }}
                           />
                           <Bar dataKey="value" radius={[2, 2, 0, 0]} barSize={40}>
                             {prepareBarChartData(currentCase).map((entry, index) => (
                               <Cell key={`cell-${index}`} fill={entry.color} fillOpacity={0.8} />
                             ))}
                           </Bar>
                         </BarChart>
                       </ResponsiveContainer>
                    </div>
                  </div>

                  <div className="bg-[#161920] border border-white/5 rounded-2xl p-8 space-y-8">
                    <h2 className="font-bold text-sm uppercase tracking-widest flex items-center gap-3 border-b border-white/5 pb-6">
                      <ClipboardCheck className="w-4 h-4 text-amber-500" />
                      Status de Conformidade
                    </h2>
                    <div className="flex-1 flex flex-col justify-center gap-12">
                        <div className="h-[200px] w-full">
                          <ResponsiveContainer width="100%" height="100%">
                            <PieChart>
                              <Pie
                                data={preparePieChartData(currentCase)}
                                cx="50%"
                                cy="50%"
                                innerRadius={70}
                                outerRadius={90}
                                paddingAngle={8}
                                dataKey="value"
                                stroke="none"
                              >
                                {preparePieChartData(currentCase).map((entry, index) => (
                                  <Cell key={`cell-${index}`} fill={entry.color} fillOpacity={0.7} />
                                ))}
                              </Pie>
                              <RechartsTooltip 
                                contentStyle={{ backgroundColor: '#0F1117', border: '1px solid rgba(255,255,255,0.05)', borderRadius: '8px' }}
                              />
                            </PieChart>
                          </ResponsiveContainer>
                        </div>
                        <div className="space-y-4">
                          {preparePieChartData(currentCase).map((entry) => (
                            <div key={entry.name} className="flex items-center justify-between text-[11px] bg-[#0F1117] p-3 rounded-xl border border-white/5">
                              <div className="flex items-center gap-3">
                                <div className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: entry.color }} />
                                <span className="text-white/40 uppercase font-bold tracking-widest">{entry.name}</span>
                              </div>
                              <span className="font-mono font-bold text-white tracking-tighter">{entry.value}</span>
                            </div>
                          ))}
                        </div>
                    </div>
                  </div>
                </div>

                {/* Legal Base Quick Access */}
                <div className="grid grid-cols-2 gap-10">
                  <div className="flex gap-6 items-start">
                    <div className="w-1.5 h-16 bg-amber-500 shrink-0" />
                    <div className="space-y-2">
                       <h5 className="text-[10px] font-black text-amber-500 uppercase tracking-[0.3em]">Alerta de Inconformidade</h5>
                       <p className="text-xs text-white/50 leading-relaxed max-w-md">
                        Identificada divergência material superior a 15% entre extrato bancário e prestação doméstica. 
                        Risco elevado de <span className="text-white font-bold">Omissão de Receita</span> ou apropriação indevida detectada por scripts automatizados.
                       </p>
                    </div>
                  </div>
                  <div className="flex gap-6 items-start">
                    <div className="w-1.5 h-16 bg-blue-500 shrink-0" />
                    <div className="space-y-2">
                       <h5 className="text-[10px] font-black text-blue-500 uppercase tracking-[0.3em]">Cálculo Institucional</h5>
                       <p className="text-xs text-white/50 leading-relaxed max-w-md">
                        Metodologia em uso: <span className="text-white font-bold">IPCA-E + Juros Moratórios de 1% a.m.</span> 
                        Parâmetros em conformidade com as diretrizes do Superior Tribunal de Justiça e Tribunal de Contas da União.
                       </p>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

            {activeTab === 'TRANSACTIONS' && (
              <motion.div 
                key="transactions"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-8"
              >
                {/* Controversy Summary Panel */}
                <div className="grid grid-cols-3 gap-6">
                  <div className="col-span-2 bg-[#0F1117] border border-white/5 rounded-2xl p-6 relative overflow-hidden">
                    <div className="absolute top-0 right-0 w-64 h-64 bg-amber-500/5 blur-3xl pointer-events-none" />
                    <div className="relative z-10 flex flex-col h-full justify-between">
                      <div className="space-y-4">
                        <div className="flex items-center justify-between">
                          <h3 className="text-[10px] font-black uppercase tracking-[0.3em] text-amber-500">Resumo de Controvérsia</h3>
                          <span className="text-[9px] text-white/20 font-mono uppercase tracking-widest">{currentCase.id}</span>
                        </div>
                        <div className="grid grid-cols-2 gap-8">
                          <div className="space-y-3">
                            <div className="flex items-start gap-3">
                              <div className="w-1.5 h-1.5 rounded-full bg-red-500 mt-1 shadow-[0_0_8px_rgba(239,68,68,0.5)]" />
                              <div>
                                <p className="text-[10px] font-bold text-white/80 uppercase">Transferência R$ 60.279,95</p>
                                <p className="text-[9px] text-white/30 leading-relaxed mt-1 italic">Operação realizada em 21/01/2019 dias antes do óbito. Indício de desvio de finalidade.</p>
                              </div>
                            </div>
                            <div className="flex items-start gap-3">
                              <div className="w-1.5 h-1.5 rounded-full bg-amber-500 mt-1 shadow-[0_0_8px_rgba(245,158,11,0.5)]" />
                              <div>
                                <p className="text-[10px] font-bold text-white/80 uppercase">Honorários (R$ 10.000,00)</p>
                                <p className="text-[9px] text-white/30 leading-relaxed mt-1 italic">Contrato Unimed Manaus sob escrutínio de vinculação com a curatela.</p>
                              </div>
                            </div>
                          </div>
                          <div className="space-y-3">
                            <div className="flex items-start gap-3">
                              <div className="w-1.5 h-1.5 rounded-full bg-blue-500 mt-1 shadow-[0_0_8px_rgba(59,130,246,0.5)]" />
                              <div>
                                <p className="text-[10px] font-bold text-white/80 uppercase">Deduções Homologadas</p>
                                <p className="text-[9px] text-white/30 leading-relaxed mt-1 italic">R$ 14.000,00 já aceitos relativos ao tratamento de José Augusto Costa.</p>
                              </div>
                            </div>
                            <div className="flex items-start gap-3">
                              <div className="w-1.5 h-1.5 rounded-full bg-purple-500 mt-1 shadow-[0_0_8px_rgba(168,85,247,0.5)]" />
                              <div>
                                <p className="text-[10px] font-bold text-white/80 uppercase">Cartões sem Fatura</p>
                                <p className="text-[9px] text-white/30 leading-relaxed mt-1 italic">Gastos sem discriminação. Risco de glosa automática conforme decisão judicial.</p>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="mt-6 pt-4 border-t border-white/5 flex items-center justify-between">
                         <div className="flex items-center gap-4">
                            <div className="flex flex-col">
                              <span className="text-[8px] font-black text-white/20 uppercase tracking-widest pl-1">Data-Base</span>
                              <span className="text-[10px] font-mono font-bold text-white/60">01/03/2019</span>
                            </div>
                            <div className="flex flex-col">
                              <span className="text-[8px] font-black text-white/20 uppercase tracking-widest pl-1">Índice Peritial</span>
                              <span className="text-[10px] font-mono font-bold text-amber-500">IPCA-E</span>
                            </div>
                         </div>
                         <button className="flex items-center gap-2 px-3 py-1.5 bg-white/5 border border-white/10 rounded-lg text-[9px] font-black uppercase tracking-widest hover:bg-white/10 transition-all">
                           <Eye className="w-3 h-3" />
                           Ver Relatório de Diligências
                         </button>
                      </div>
                    </div>
                  </div>
                  <div className="bg-[#161920] border border-white/5 rounded-2xl p-6 flex flex-col justify-center gap-4 group hover:border-amber-500/20 transition-all">
                    <div className="flex items-center justify-between">
                      <div className="w-10 h-10 rounded-xl bg-amber-500/10 flex items-center justify-center text-amber-500 border border-amber-500/20 group-hover:scale-110 transition-transform">
                        <Scale className="w-5 h-5" />
                      </div>
                      <span className="text-[8px] font-black text-white/20 uppercase tracking-widest">Sentença de Liquidação</span>
                    </div>
                    <div>
                      <h4 className="text-sm font-bold text-white mb-1 uppercase tracking-tight">Vara de Família e Órfãos - Guará</h4>
                      <p className="text-[10px] text-white/40 leading-relaxed">Nomeação em 02/03/2026. Honorários fixados em R$ 1.900,00 (Portaria 116/2024).</p>
                    </div>
                    <div className="mt-auto h-2 bg-white/5 rounded-full overflow-hidden">
                       <motion.div 
                        initial={{ width: 0 }}
                        animate={{ width: '45%' }}
                        className="h-full bg-amber-500 shadow-[0_0_10px_rgba(245,158,11,0.5)]" 
                       />
                    </div>
                  </div>
                </div>

                <div className="bg-[#161920] border border-white/5 rounded-2xl overflow-hidden shadow-2xl">
                <div className="p-8 border-b border-white/5 flex items-center justify-between bg-[#0F1117]">
                  <div>
                    <h2 className="font-bold text-sm uppercase tracking-widest text-[#E0E0E0]">Demonstrativo de Confronto Analítico</h2>
                    <p className="text-[10px] text-white/30 uppercase tracking-[0.15em] font-bold mt-1">Escrutínio Documental e Rastreabilidade Financeira</p>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="flex items-center bg-[#0A0C10] border border-white/5 rounded-lg px-4 py-2 gap-3 group focus-within:border-amber-500/50 transition-all">
                      <Search className="w-4 h-4 text-white/20 group-hover:text-white/40" />
                      <input 
                        type="text" 
                        placeholder="FILTRAR POR BASE LEGAL..." 
                        value={legalSearchQuery}
                        onChange={(e) => setLegalSearchQuery(e.target.value)}
                        className="text-[10px] uppercase font-bold tracking-widest outline-none w-56 text-white bg-transparent italic" 
                      />
                    </div>
                    <button className="bg-amber-500 text-black px-5 py-2 rounded-lg text-[10px] font-black uppercase tracking-widest hover:bg-amber-400 transition-all shadow-lg shadow-amber-500/10">Novo Registro</button>
                  </div>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse">
                    <thead className="bg-[#0F1117] text-[10px] uppercase tracking-[0.3em] text-white/20 font-black border-b border-white/5">
                      <tr>
                        <th className="px-8 py-5 w-10">
                          <button onClick={toggleSelectAll} className="text-white/20 hover:text-white transition-colors">
                            {selectedTransactionIds.length === currentCase.transactions.length && currentCase.transactions.length > 0
                              ? <CheckSquare className="w-4 h-4 text-amber-500" />
                              : <Square className="w-4 h-4" />
                            }
                          </button>
                        </th>
                        <th className="px-8 py-5 font-black">Data</th>
                        <th className="px-8 py-5 font-black">Descrição Detalhada</th>
                        <th className="px-8 py-5 font-black">Natureza</th>
                        <th className="px-8 py-5 font-black text-right">Montante (R$)</th>
                        <th className="px-8 py-5 font-black text-center">Suporte</th>
                        <th className="px-8 py-5 font-black">Parecer Pericial</th>
                        <th className="px-8 py-5"></th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-white/5 text-[11px] font-mono">
                      {currentCase.transactions
                        .filter(t => !legalSearchQuery || t.legalBasis?.toLowerCase().includes(legalSearchQuery.toLowerCase()))
                        .map((t) => (
                        <React.Fragment key={t.id}>
                          <tr 
                            onClick={() => setExpandedTransactionId(expandedTransactionId === t.id ? null : t.id)}
                            onDragOver={(e) => onDragOver(e, t.id)}
                            onDragLeave={onDragLeave}
                            onDrop={(e) => onDrop(e, t.id)}
                            className={cn(
                              "hover:bg-white/5 transition-all group cursor-pointer relative",
                              expandedTransactionId === t.id && "bg-amber-500/5",
                              selectedTransactionIds.includes(t.id) && "bg-white/[0.02]",
                              draggingId === t.id && "bg-amber-500/10 scale-[1.01] z-10 shadow-xl"
                            )}
                          >
                            {draggingId === t.id && (
                              <div className="absolute inset-0 border-2 border-amber-500 border-dashed rounded-lg pointer-events-none flex items-center justify-center bg-amber-500/5 z-20">
                                <div className="bg-amber-500 text-black px-4 py-2 rounded-full text-[10px] font-black uppercase tracking-widest shadow-2xl animate-bounce">
                                  Solte para Vincular Documento
                                </div>
                              </div>
                            )}
                            <td className="px-8 py-5">
                              <button 
                                onClick={(e) => toggleSelectTransaction(t.id, e)}
                                className={cn(
                                  "transition-colors",
                                  selectedTransactionIds.includes(t.id) ? "text-amber-500" : "text-white/5 hover:text-white/20"
                                )}
                              >
                                {selectedTransactionIds.includes(t.id) ? <CheckSquare className="w-4 h-4" /> : <Square className="w-4 h-4" />}
                              </button>
                            </td>
                            <td className="px-8 py-5 text-white/40 tracking-tighter">{t.date}</td>
                            <td className="px-8 py-5">
                              <div className="flex flex-col gap-1">
                                <div className="flex items-center gap-2">
                                  <span className="text-white/80 font-bold uppercase tracking-tight truncate">{t.description}</span>
                                  {t.isAgreedDeduction && (
                                    <div className="group relative">
                                      <div className="px-1.5 py-0.5 bg-blue-500/10 border border-blue-500/20 rounded text-[7px] font-black text-blue-400 uppercase tracking-widest leading-none">Acordado</div>
                                      <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 px-2 py-1 bg-black text-[8px] font-black text-white uppercase tracking-widest rounded border border-white/10 opacity-0 group-hover:opacity-100 transition-all pointer-events-none whitespace-nowrap z-30">Dedução já aceita pelo Espólio</div>
                                    </div>
                                  )}
                                  {t.requiresDiligence && (
                                    <div className="group relative">
                                      <div className="w-4 h-4 bg-amber-500/10 border border-amber-500/20 rounded flex items-center justify-center text-amber-500">
                                        <Info className="w-2.5 h-2.5" />
                                      </div>
                                      <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 px-2 py-1 bg-black text-[8px] font-black text-amber-500 uppercase tracking-widest rounded border border-amber-500/30 opacity-0 group-hover:opacity-100 transition-all pointer-events-none whitespace-nowrap z-30">Diligência Solicitada</div>
                                    </div>
                                  )}
                                  {t.isIllegible && (
                                    <div className="group relative">
                                      <div className="w-4 h-4 bg-red-500/10 border border-red-500/20 rounded flex items-center justify-center text-red-500">
                                        <Eye className="w-2.5 h-2.5" />
                                      </div>
                                      <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 px-2 py-1 bg-black text-[8px] font-black text-red-500 uppercase tracking-widest rounded border border-red-500/30 opacity-0 group-hover:opacity-100 transition-all pointer-events-none whitespace-nowrap z-30">Ilegível / Inidôneo</div>
                                    </div>
                                  )}
                                </div>
                                {t.legalBasis && (
                                  <div className="flex items-center gap-1.5">
                                    <span className="px-1.5 py-0.5 bg-amber-500/10 text-amber-500/70 text-[8px] font-black rounded border border-amber-500/20 uppercase tracking-widest leading-none">
                                      {t.legalBasis}
                                    </span>
                                  </div>
                                )}
                              </div>
                            </td>
                            <td className="px-8 py-5">
                              <span className={cn(
                                "px-2 py-0.5 rounded text-[9px] font-black uppercase tracking-widest",
                                t.type === 'INFLOW' ? "bg-green-500/10 text-green-400 border border-green-500/20" : "bg-blue-500/10 text-blue-400 border border-blue-500/20"
                              )}>{t.category}</span>
                            </td>
                            <td className={cn(
                              "px-8 py-5 text-right font-black tracking-tighter",
                              t.type === 'INFLOW' ? "text-green-400" : "text-white"
                            )}>
                              {t.type === 'INFLOW' ? '+' : '-'} {t.value.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                            </td>
                            <td className="px-8 py-5">
                              <div className="flex items-center justify-center gap-3">
                                {t.hasDocument ? (
                                   <div className="flex items-center gap-2">
                                     <div className="group/doc relative cursor-help">
                                       <CheckCircle2 className="w-4 h-4 text-green-500/40" />
                                       <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 px-2 py-1 bg-black text-[8px] font-black text-green-400 uppercase tracking-widest rounded border border-green-500/30 opacity-0 group-hover/doc:opacity-100 transition-all pointer-events-none whitespace-nowrap">Nota Fiscal Vinculada</div>
                                     </div>
                                     <button 
                                       onClick={(e) => { e.stopPropagation(); setPreviewTransactionId(t.id); }}
                                       className="p-1.5 rounded-lg bg-green-500/10 border border-green-500/20 text-green-500 hover:bg-green-500/20 transition-all group/prev"
                                       title="Visualizar Evidência"
                                     >
                                       <Eye className="w-3.5 h-3.5 group-hover/prev:scale-110 transition-transform" />
                                     </button>
                                   </div>
                                 ) : (
                                  <div className="group/doc relative cursor-help">
                                    <AlertCircle className="w-4 h-4 text-red-500/60" />
                                    <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 px-2 py-1 bg-black text-[8px] font-black text-red-400 uppercase tracking-widest rounded border border-red-500/30 opacity-0 group-hover/doc:opacity-100 transition-all pointer-events-none whitespace-nowrap shadow-xl">Falta de Comprovação</div>
                                  </div>
                                )}
                                <button 
                                  onClick={(e) => { e.stopPropagation(); setUploadingTransactionId(t.id); }}
                                  className="group/up p-1.5 rounded-lg bg-[#0F1117] border border-white/5 hover:border-amber-500/40 hover:bg-amber-500/10 text-white/10 hover:text-amber-500 transition-all"
                                  title="Anexar Comprovante Forense"
                                >
                                  <FileUp className="w-3.5 h-3.5 group-hover/up:scale-110 transition-transform" />
                                </button>
                              </div>
                            </td>
                            <td className="px-8 py-5">
                              <div className="flex flex-col gap-1.5">
                                <StatusBadge status={t.status} />
                                {t.peritialNotes && (
                                  <div className="flex items-center gap-1.5 text-white/40 italic">
                                    <ClipboardCheck className="w-3 h-3 text-amber-500/50" />
                                    <span className="text-[9px] truncate max-w-[120px]">{t.peritialNotes}</span>
                                  </div>
                                )}
                              </div>
                            </td>
                            <td className="px-8 py-5 text-right">
                              <button className={cn(
                                "text-white/10 group-hover:text-amber-500 transition-all p-1",
                                expandedTransactionId === t.id && "rotate-180 text-amber-500"
                              )}>
                                <ChevronDown className="w-4 h-4" />
                              </button>
                            </td>
                          </tr>
                          <AnimatePresence>
                            {expandedTransactionId === t.id && (
                              <tr>
                                <td colSpan={8} className="px-8 py-0 border-none">
                                  <motion.div
                                    initial={{ height: 0, opacity: 0 }}
                                    animate={{ height: 'auto', opacity: 1 }}
                                    exit={{ height: 0, opacity: 0 }}
                                    transition={{ duration: 0.2 }}
                                    className="overflow-hidden"
                                  >
                                    <div className="py-8 grid grid-cols-4 gap-12 border-t border-white/5">
                                      <div className="space-y-3">
                                        <h4 className="text-[9px] uppercase tracking-[0.2em] text-white/30 font-black">Justificativa Pericial</h4>
                                        <div className={cn(
                                          "p-4 rounded-xl border space-y-3",
                                          t.status === 'GLOSSED' ? "bg-red-500/5 border-red-500/20" : "bg-[#0A0C10] border-white/5"
                                        )}>
                                          <p className={cn(
                                            "text-[10px] leading-relaxed italic",
                                            t.status === 'GLOSSED' ? "text-red-400" : "text-white/60"
                                          )}>
                                            {t.status === 'GLOSSED' 
                                              ? 'Divergência Detectada:' 
                                              : t.status === 'ACCEPTED' 
                                                ? 'Item Regular:'
                                                : 'Aguardando Análise:'}
                                          </p>
                                          {t.status === 'GLOSSED' ? (
                                            <div className="space-y-4">
                                              <div className="flex items-center gap-2 mb-2">
                                                <div className="w-1.5 h-1.5 bg-red-500 rounded-full animate-pulse" />
                                                <span className="text-[8px] font-black text-red-500 uppercase tracking-[0.2em]">Parecer de Glosa Ativo</span>
                                              </div>
                                              <div className="space-y-1.5">
                                                <label className="text-[8px] uppercase font-black text-red-400/60 tracking-widest pl-1">Razão Técnica Principal</label>
                                                <textarea 
                                                  value={t.glosaReason || ''} 
                                                  onChange={(e) => handleGlosaReasonChange(t.id, e.target.value)}
                                                  placeholder="Ex: Documentação inidônea ou ausência de nexo causal..."
                                                  className="w-full h-16 bg-black/40 border border-red-500/20 rounded-lg p-2 text-[10px] text-red-200 outline-none focus:border-red-500/50 resize-none font-bold"
                                                />
                                              </div>
                                              <div className="space-y-1.5">
                                                <div className="flex items-center gap-2 pl-1">
                                                  <ClipboardCheck className="w-3 h-3 text-red-400/50" />
                                                  <label className="text-[8px] uppercase font-black text-red-400/60 tracking-widest">Notas Específicas da Glosa</label>
                                                </div>
                                                <textarea 
                                                  value={t.glosaNotes || ''} 
                                                  onChange={(e) => handleGlosaNotesChange(t.id, e.target.value)}
                                                  placeholder="Insira aqui detalhes específicos que embasam esta glosa..."
                                                  className="w-full h-24 bg-black/50 border border-red-500/20 rounded-lg p-2.5 text-[10px] text-red-200 outline-none focus:border-red-500/50 resize-none font-medium"
                                                />
                                                <div className="flex justify-end pr-1">
                                                  <span className="text-[7px] text-red-500/40 uppercase font-black tracking-widest italic animate-pulse">Auto-Salvamento Ativo</span>
                                                </div>
                                              </div>
                                              <div className="p-2 bg-red-500/10 rounded border border-red-500/20 flex items-start gap-2">
                                                <AlertCircle className="w-3 h-3 text-red-400 shrink-0 mt-0.5" />
                                                <p className="text-[8px] text-red-400/80 uppercase font-bold leading-normal">Esta glosa deduz o valor integral do saldo final do período analisado.</p>
                                              </div>
                                            </div>
                                          ) : (
                                            <p className="text-[10px] text-white/40 leading-relaxed">
                                              {t.status === 'ACCEPTED' 
                                                ? 'A transação apresenta conformidade com os documentos suporte e extratos verificados.' 
                                                : 'Este item requer verificação manual de autenticidade ou vínculo com o extrato bancário.'}
                                            </p>
                                          )}
                                        </div>
                                      </div>
                                      <div className="col-span-1 space-y-3">
                                        <h4 className="text-[9px] uppercase tracking-[0.2em] text-white/30 font-black">Enquadramento Legal</h4>
                                        <select 
                                          value={t.legalBasis || ''} 
                                          onChange={(e) => handleLegalBasisChange(t.id, e.target.value)}
                                          className="w-full bg-[#0A0C10] border border-white/10 rounded-xl px-3 py-2 text-[10px] text-white/80 outline-none focus:border-amber-500/50 transition-all appearance-none cursor-pointer"
                                        >
                                          <option value="" className="text-white/20 italic">Selecione a Base Legal...</option>
                                          {Object.entries(LEGAL_BASES).map(([group, bases]) => (
                                            <optgroup key={group} label={group === 'JUDICIAL' ? 'Esfera Judicial' : group === 'ADMINISTRATIVE' ? 'Esfera Administrativa' : 'Esfera Privada'} className="bg-[#161920] text-amber-500 font-black text-[9px] uppercase tracking-widest pt-2">
                                              {bases.map(b => (
                                                <option key={b.code} value={b.code} className="bg-[#0A0C10] text-white/80 font-mono">
                                                  {b.code} - {b.title}
                                                </option>
                                              ))}
                                            </optgroup>
                                          ))}
                                        </select>
                                        <h4 className="text-[9px] uppercase tracking-[0.2em] text-white/30 font-black pt-2">Observações de Exame Forense</h4>
                                        <textarea 
                                          value={t.peritialNotes || ''} 
                                          onChange={(e) => handlePeritialNotesChange(t.id, e.target.value)}
                                          placeholder="Descreva aqui considerações técnicas, indícios ou evidências encontradas no escrutínio desta transação..."
                                          className="w-full h-24 bg-[#0A0C10] border border-white/10 rounded-xl p-3 text-[10px] text-white/80 placeholder:text-white/20 outline-none focus:border-amber-500/50 transition-all resize-none shadow-inner"
                                        />
                                        <h4 className="text-[9px] uppercase tracking-[0.2em] text-white/30 font-black pt-2">Notas e Observações Gerais</h4>
                                        <textarea 
                                          value={t.generalNotes || ''} 
                                          onChange={(e) => handleGeneralNotesChange(t.id, e.target.value)}
                                          placeholder="Insira notas gerais, lembretes ou observações administrativas sobre esta transação..."
                                          className="w-full h-24 bg-[#0A0C10] border border-white/10 rounded-xl p-3 text-[10px] text-white/80 placeholder:text-white/20 outline-none focus:border-amber-500/50 transition-all resize-none shadow-inner"
                                        />
                                      </div>
                                      <div className="space-y-4">
                                        <div className="flex items-center justify-between">
                                          <h4 className="text-[9px] uppercase tracking-[0.2em] text-white/30 font-black">Metadados de Auditoria</h4>
                                          {t.isIllegible && (
                                            <div className="flex items-center gap-1 px-1.5 py-0.5 rounded-full bg-red-500/10 border border-red-500/20">
                                              <AlertCircle className="w-2 h-2 text-red-500" />
                                              <span className="text-[7px] text-red-500 font-black uppercase">Crítico: Ilegível</span>
                                            </div>
                                          )}
                                        </div>

                                        <div className="bg-[#0A0C10] border border-white/5 rounded-xl overflow-hidden p-4 space-y-4">
                                          {t.requiresDiligence && (
                                            <div className="p-3 bg-amber-500/5 border border-amber-500/10 rounded-lg space-y-2">
                                              <div className="flex items-center gap-2">
                                                <History className="w-3 h-3 text-amber-500" />
                                                <span className="text-[8px] font-black text-amber-500 uppercase tracking-widest">Workflow de Diligência</span>
                                              </div>
                                              <p className="text-[10px] text-white/60 leading-relaxed italic pr-2">
                                                {t.diligenceDescription || 'Necessária ação corretiva do prestador para validação deste item.'}
                                              </p>
                                              <div className="flex justify-end">
                                                <button className="text-[8px] font-black text-white/20 hover:text-white uppercase tracking-widest border border-white/5 px-2 py-1 rounded hover:bg-white/5 transition-all">
                                                  Gerar Ofício de Requisição
                                                </button>
                                              </div>
                                            </div>
                                          )}

                                          {t.isAgreedDeduction && (
                                            <div className="p-3 bg-blue-500/5 border border-blue-500/10 rounded-lg space-y-1">
                                              <div className="flex items-center gap-2">
                                                <CheckCircle2 className="w-3 h-3 text-blue-500" />
                                                <span className="text-[8px] font-black text-blue-500 uppercase tracking-widest">Dedução Homologada</span>
                                              </div>
                                              <p className="text-[10px] text-white/60 leading-relaxed italic">
                                                Valor já aceito pela parte requerente como legítimo para tratamento de José Augusto Costa.
                                              </p>
                                            </div>
                                          )}

                                          <div className="flex flex-col gap-2">
                                            <div className="flex items-center justify-between text-[10px]">
                                              <span className="text-white/20 uppercase font-black text-[8px] tracking-widest">Protocolo Forense:</span>
                                              <span className="text-amber-500/40 font-mono font-bold tracking-tight">{(t.id + t.date).split('').reduce((a, b) => (a << 5) - a + b.charCodeAt(0), 0).toString(16).toUpperCase()}</span>
                                            </div>
                                            <div className="flex items-center justify-between text-[10px]">
                                              <span className="text-white/20 uppercase font-black text-[8px] tracking-widest">Status de Auditoria:</span>
                                              <span className="text-white/60 font-bold uppercase pr-1">{t.status === 'ACCEPTED' ? 'Auditado v.1.0' : t.status === 'GLOSSED' ? 'Glosa Técnica' : 'Em Escrutínio'}</span>
                                            </div>
                                          </div>
                                        </div>

                                        <div className="flex items-center justify-between pt-2">
                                          <h4 className="text-[9px] uppercase tracking-[0.2em] text-white/30 font-black">Checklist de Evidências</h4>
                                          {t.checklist && t.checklist.length > 0 && (
                                            <div className="flex items-center gap-1">
                                              {t.checklist.every(i => i.status === 'VALIDATED') ? (
                                                <div className="flex items-center gap-1 px-1.5 py-0.5 rounded-full bg-green-500/10 border border-green-500/20">
                                                  <ShieldCheck className="w-2 h-2 text-green-500" />
                                                  <span className="text-[7px] text-green-500 font-black uppercase">Forense OK</span>
                                                </div>
                                              ) : (
                                                <div className="flex items-center gap-1 px-1.5 py-0.5 rounded-full bg-amber-500/10 border border-amber-500/20">
                                                  <ShieldAlert className="w-2 h-2 text-amber-500" />
                                                  <span className="text-[7px] text-amber-500 font-black uppercase">Incompleto</span>
                                                </div>
                                              )}
                                            </div>
                                          )}
                                        </div>
                                        
                                        <div className="bg-[#0A0C10] border border-white/5 rounded-xl overflow-hidden">
                                          <div className="p-3 space-y-2.5">
                                            {(t.checklist || getInitialChecklist(t.category)).map((item) => (
                                              <div key={item.id} className="flex items-start justify-between gap-3 group/item">
                                                <div className="flex items-center gap-2">
                                                  <div className={cn(
                                                    "w-4 h-4 rounded flex items-center justify-center transition-all",
                                                    item.status === 'VALIDATED' ? "bg-green-500/20 text-green-500" : 
                                                    item.status === 'MISSING' ? "bg-red-500/20 text-red-500" : "bg-white/5 text-white/20"
                                                  )}>
                                                    {item.status === 'VALIDATED' ? <CheckCircle2 className="w-2.5 h-2.5" /> : 
                                                     item.status === 'MISSING' ? <AlertCircle className="w-2.5 h-2.5" /> : <Clock className="w-2.5 h-2.5" />}
                                                  </div>
                                                  <span className={cn(
                                                    "text-[10px] font-medium transition-colors",
                                                    item.status === 'VALIDATED' ? "text-white/80" : 
                                                    item.status === 'MISSING' ? "text-red-400" : "text-white/40"
                                                  )}>
                                                    {item.label}
                                                  </span>
                                                </div>
                                                <span className={cn(
                                                  "text-[7px] uppercase font-black tracking-widest px-1 py-0.5 rounded",
                                                  item.status === 'VALIDATED' ? "bg-green-500/10 text-green-500" : 
                                                  item.status === 'MISSING' ? "bg-red-500/10 text-red-500" : "bg-white/5 text-white/20"
                                                )}>
                                                  {item.status === 'VALIDATED' ? 'Validado' : 
                                                   item.status === 'MISSING' ? 'Pendente' : 'Aguardando'}
                                                </span>
                                              </div>
                                            ))}
                                          </div>
                                          
                                          {(!t.checklist || t.checklist.length === 0) && (
                                            <div className="px-4 py-3 bg-amber-500/5 border-t border-white/5 flex flex-col items-center justify-center gap-2 text-center">
                                              <ListChecks className="w-5 h-5 text-amber-500/40" />
                                              <p className="text-[8px] text-amber-500/60 uppercase font-bold leading-normal">
                                                Aguardando upload de documento para validação automática de requisitos.
                                              </p>
                                            </div>
                                          )}
                                        </div>

                                        <div className="space-y-3 pt-2">
                                          <h4 className="text-[9px] uppercase tracking-[0.2em] text-white/30 font-black">Rastreabilidade</h4>
                                        <div className="flex flex-col gap-2">
                                          <div className="flex items-center justify-between text-[10px]">
                                            <span className="text-white/20">Hash de Registro:</span>
                                            <span className="text-amber-500/40 font-bold tracking-tight">{(t.id + t.date).split('').reduce((a, b) => (a << 5) - a + b.charCodeAt(0), 0).toString(16).toUpperCase()}</span>
                                          </div>
                                          <div className="flex items-center justify-between text-[10px]">
                                            <span className="text-white/20">Última Edição:</span>
                                            <span className="text-white/60">SISTEMA_AUTO_PERICIA</span>
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                    <div className="space-y-3">
                                        <h4 className="text-[9px] uppercase tracking-[0.2em] text-white/30 font-black">Ações e Documentos</h4>
                                        <div className="flex flex-col gap-2">
                                          {t.hasDocument ? (
                                            <div className="flex flex-col gap-2 w-full">
                                              <div className="flex items-center gap-2 w-full">
                                                <a 
                                                  href={`#preview-${t.id}`} 
                                                  onClick={(e) => { e.preventDefault(); setPreviewTransactionId(t.id); }}
                                                  className="flex-1 flex items-center gap-2 bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/30 px-3 py-2 rounded-lg transition-all group/btn text-amber-500"
                                                >
                                                  <Paperclip className="w-3 h-3" />
                                                  <span className="text-[9px] uppercase font-black tracking-widest truncate">{t.documentRef || 'Documento'}</span>
                                                  <Eye className="w-3 h-3 opacity-40 group-hover/btn:opacity-100 ml-auto" />
                                                </a>
                                                <button 
                                                  onClick={() => alert(`Iniciando download de: ${t.documentRef || 'documento'}.pdf`)}
                                                  className="p-2 bg-[#0A0C10] hover:bg-white/5 border border-white/10 rounded-lg text-white/20 hover:text-amber-500 transition-all"
                                                  title="Download"
                                                >
                                                  <Download className="w-3 h-3" />
                                                </button>
                                              </div>
                                              <label className="cursor-pointer flex items-center gap-2 bg-[#0A0C10] hover:bg-white/5 border border-white/10 px-3 py-2 rounded-lg transition-all group/btn">
                                                <Upload className="w-3 h-3 text-white/20 group-hover/btn:text-amber-500" />
                                                <span className="text-[9px] uppercase font-black tracking-widest text-white/40 group-hover/btn:text-white">Substituir</span>
                                                <input type="file" className="hidden" onChange={(e) => handleFileUpload(t.id, e)} />
                                              </label>
                                            </div>
                                          ) : (
                                            <div 
                                              onDragOver={(e) => onDragOver(e, t.id)}
                                              onDragLeave={onDragLeave}
                                              onDrop={(e) => onDrop(e, t.id)}
                                              className={cn(
                                                "relative w-full border-2 border-dashed rounded-xl transition-all duration-200 flex flex-col items-center justify-center gap-3 p-4",
                                                draggingId === t.id 
                                                  ? "border-amber-500 bg-amber-500/5 scale-[1.02]" 
                                                  : "border-white/5 bg-[#0A0C10] hover:border-white/20"
                                              )}
                                            >
                                              <div className={cn(
                                                "w-8 h-8 rounded-full flex items-center justify-center transition-colors",
                                                draggingId === t.id ? "bg-amber-500 text-black" : "bg-white/5 text-white/20"
                                              )}>
                                                <Upload className="w-4 h-4" />
                                              </div>
                                              <div className="text-center group-hover:scale-105 transition-transform duration-500">
                                                <p className="text-[9px] font-black uppercase tracking-[0.2em] text-white/80 group-hover:text-white transition-colors">Arraste a Evidência</p>
                                                <div className="mt-3 flex items-center justify-center gap-2">
                                                  <div className="h-[1px] w-4 bg-white/5" />
                                                  <p className="text-[8px] text-white/10 uppercase font-black tracking-widest italic">ou</p>
                                                  <div className="h-[1px] w-4 bg-white/5" />
                                                </div>
                                                <button className="mt-3 px-4 py-1.5 bg-[#0A0C10] border border-white/10 rounded-lg text-[8px] font-black uppercase tracking-widest text-white/40 group-hover:text-amber-500 group-hover:border-amber-500/30 transition-all shadow-xl">
                                                  Selecionar Arquivo
                                                </button>
                                              </div>
                                              <input 
                                                type="file" 
                                                className="absolute inset-0 opacity-0 cursor-pointer" 
                                                onChange={(e) => handleFileUpload(t.id, e)}
                                              />
                                            </div>
                                          )}
                                          <button className="w-full mt-2 flex items-center gap-2 bg-[#0A0C10] hover:bg-white/5 border border-white/10 px-3 py-2 rounded-lg transition-all group/btn text-white/40">
                                            <FileText className="w-3 h-3 group-hover/btn:text-amber-500" />
                                            <span className="text-[9px] uppercase font-black tracking-widest group-hover/btn:text-white">Emitir Parecer Local</span>
                                          </button>
                                        </div>
                                      </div>
                                    </div>
                                  </motion.div>
                                </td>
                              </tr>
                            )}
                          </AnimatePresence>
                        </React.Fragment>
                      ))}
                    </tbody>
                  </table>
                </div>

                {/* Bulk Action Bar */}
                <AnimatePresence>
                  {selectedTransactionIds.length > 0 && (
                    <motion.div 
                      initial={{ y: 100, opacity: 0 }}
                      animate={{ y: 0, opacity: 1 }}
                      exit={{ y: 100, opacity: 0 }}
                      className="fixed bottom-10 left-1/2 -translate-x-1/2 bg-[#0F1117] border border-amber-500/30 rounded-2xl p-4 shadow-2xl z-50 flex items-center gap-8 min-w-[400px]"
                    >
                      <div className="flex items-center gap-4 border-r border-white/5 pr-8">
                        <div className="bg-amber-500 text-black w-6 h-6 rounded-full flex items-center justify-center font-black text-[10px]">
                          {selectedTransactionIds.length}
                        </div>
                        <span className="text-[10px] uppercase font-black tracking-widest text-white/60">Selecionados</span>
                      </div>
                      
                      <div className="flex-1 relative">
                        <button 
                          onClick={() => setShowBulkDropdown(!showBulkDropdown)}
                          className="w-full flex items-center justify-between bg-amber-500 text-black px-6 py-2.5 rounded-lg text-[10px] font-black uppercase tracking-widest hover:bg-amber-400 transition-all shadow-lg shadow-amber-500/10"
                        >
                          Ações em Lote
                          <ChevronDown className={cn("w-4 h-4 transition-transform", showBulkDropdown && "rotate-180")} />
                        </button>

                        <AnimatePresence>
                          {showBulkDropdown && (
                            <motion.div 
                              initial={{ opacity: 0, y: 10, scale: 0.95 }}
                              animate={{ opacity: 1, y: -8, scale: 1 }}
                              exit={{ opacity: 0, y: 10, scale: 0.95 }}
                              className="absolute bottom-full left-0 w-full bg-[#161920] border border-white/10 rounded-xl shadow-2xl overflow-hidden mb-2"
                            >
                              <div className="p-2 space-y-1">
                                <BulkActionItem 
                                  onClick={() => handleBulkStatusChange('ACCEPTED')} 
                                  icon={<CheckCircle2 className="w-3.5 h-3.5 text-green-500" />} 
                                  label="Validar/Aceitar" 
                                />
                                <BulkActionItem 
                                  onClick={() => handleBulkStatusChange('GLOSSED')} 
                                  icon={<AlertCircle className="w-3.5 h-3.5 text-red-500" />} 
                                  label="Glosar Transações" 
                                />
                                <BulkActionItem 
                                  onClick={() => handleBulkStatusChange('PENDING')} 
                                  icon={<Clock className="w-3.5 h-3.5 text-amber-500" />} 
                                  label="Colocar em Diligência" 
                                />
                                <div className="h-px bg-white/5 my-1" />
                                <BulkActionItem 
                                  onClick={() => { setSelectedTransactionIds([]); setShowBulkDropdown(false); }} 
                                  icon={<Ban className="w-3.5 h-3.5 text-white/20" />} 
                                  label="Cancelar Seleção" 
                                  variant="secondary"
                                />
                              </div>
                            </motion.div>
                          )}
                        </AnimatePresence>
                      </div>

                      <button 
                        onClick={() => setSelectedTransactionIds([])}
                        className="text-white/20 hover:text-white transition-colors"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </motion.div>
                  )}
                </AnimatePresence>
                </div>
              </motion.div>
            )}

            {activeTab === 'RECONCILIATION' && (
              <motion.div 
                key="reconciliation"
                initial={{ opacity: 0, scale: 0.98 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.98 }}
                className="grid grid-cols-2 gap-10"
              >
                <div className="bg-[#161920] rounded-2xl border border-white/5 p-10 space-y-8 relative overflow-hidden">
                  <div className="absolute top-0 left-0 w-32 h-32 bg-blue-500/5 blur-3xl" />
                  <div className="flex items-center gap-4 border-b border-white/5 pb-8">
                    <div className="w-12 h-12 rounded-xl bg-blue-500/10 flex items-center justify-center text-blue-500 border border-blue-500/20">
                      <Building2 className="w-6 h-6" />
                    </div>
                    <div>
                      <h3 className="font-black text-sm uppercase tracking-widest">Base de Dados: Bancário</h3>
                      <p className="text-[10px] text-white/30 uppercase tracking-[0.2em] font-bold mt-1">Confronte com Extratos Bancários (CSV/OFX)</p>
                    </div>
                  </div>
                  <div className="bg-[#0F1117] rounded-2xl p-10 border border-dashed border-white/10 flex flex-col items-center justify-center gap-5 h-72 group cursor-pointer hover:border-amber-500/30 hover:bg-[#161920] transition-all">
                    <div className="w-16 h-16 rounded-full bg-white/5 flex items-center justify-center group-hover:scale-110 transition-transform">
                      <Plus className="w-8 h-8 text-white/10 group-hover:text-amber-500" />
                    </div>
                    <div className="text-center">
                      <p className="text-[10px] font-black text-white/30 uppercase tracking-[0.3em] group-hover:text-amber-500/60 transition-colors">Importar Dataset Externo</p>
                      <p className="text-[9px] text-white/10 font-mono mt-2 italic group-hover:text-white/20">SUPORTA: .CSV, .XLSX, .OFX</p>
                    </div>
                  </div>
                </div>

                <div className="bg-[#161920] rounded-2xl border border-white/5 p-10 space-y-8 relative overflow-hidden">
                  <div className="absolute top-0 right-0 w-32 h-32 bg-amber-500/5 blur-3xl" />
                  <div className="flex items-center gap-4 border-b border-white/5 pb-8">
                    <div className="w-12 h-12 rounded-xl bg-amber-500/10 flex items-center justify-center text-amber-500 border border-amber-500/20">
                      <ClipboardCheck className="w-6 h-6" />
                    </div>
                    <div>
                      <h3 className="font-black text-sm uppercase tracking-widest">Relatório Analítico</h3>
                      <p className="text-[10px] text-white/30 uppercase tracking-[0.2em] font-bold mt-1">Resultados da Prestação Auditada</p>
                    </div>
                  </div>
                  <div className="grid grid-cols-1 gap-4">
                    <ReconItem label="Saldo Inicial" value={currentCase.initialBalance} />
                    <ReconItem label="Total de Entradas" value={currentCase.transactions.filter(t => t.type === 'INFLOW').reduce((acc, t) => acc + t.value, 0)} color="text-green-400" />
                    <ReconItem label="Total de Saídas" value={currentCase.transactions.filter(t => t.type === 'OUTFLOW').reduce((acc, t) => acc + t.value, 0)} color="text-red-400" />
                    <div className="p-6 bg-amber-500/5 rounded-2xl border border-amber-500/20 flex flex-col gap-2 mt-4 shadow-inner">
                      <span className="text-[9px] font-black uppercase tracking-[0.4em] text-amber-500/60">Saldo Final Apurado</span>
                      <span className="text-3xl font-mono font-black text-amber-500 tracking-tighter">{formatCurrency(currentCase.finalBalance)}</span>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

            {activeTab === 'REPORT' && (
              <motion.div 
                key="report"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="max-w-4xl mx-auto bg-white shadow-[0_0_100px_rgba(0,0,0,0.5)] min-h-[1100px] p-24 flex flex-col gap-16 border rounded-sm text-black"
              >
                <div className="flex justify-between items-start border-b-[6px] border-[#0A0C10] pb-10">
                  <div className="space-y-4">
                    <div className="flex items-center gap-3 bg-[#0A0C10] text-white w-fit px-3 py-1 rounded text-[10px] font-black uppercase tracking-widest">
                      <Scale className="w-3 h-3 text-amber-500" />
                      Documento Pericial
                    </div>
                    <h1 className="text-4xl font-serif italic font-black uppercase tracking-tighter text-[#0A0C10]">Laudo Forense Contábil</h1>
                    <div className="flex items-center gap-6 text-[10px] font-mono text-gray-400 font-bold uppercase tracking-widest leading-none">
                      <span className="flex items-center gap-2">ID: <span className="text-black">{currentCase.id}</span></span>
                      <span className="flex items-center gap-2">Juízo: <span className="text-black">2ª V. CÍVEL - CAPITAL</span></span>
                    </div>
                  </div>
                  <div className="text-right flex flex-col gap-2">
                    <div className="flex items-center gap-3 justify-end text-black">
                      <div className="w-8 h-8 bg-amber-500 rounded flex items-center justify-center text-black font-black text-lg">Σ</div>
                      <span className="font-black tracking-widest text-sm uppercase">Skill Pericial</span>
                    </div>
                    <p className="text-[9px] text-gray-400 uppercase tracking-widest font-black italic">V. 2024_Q1_PRO</p>
                  </div>
                </div>

                <div className="space-y-16 text-[#1A1A1A] leading-relaxed">
                  <section className="space-y-6">
                    <h2 className="text-[11px] uppercase tracking-[0.4em] font-black text-gray-300 border-b-2 pb-2">I. INTRODUÇÃO E ESCOPO</h2>
                    <p className="text-sm font-medium leading-[1.8]">O presente trabalho pericial consitui-se na análise técnica das contas apresentadas por <strong>{currentCase.responsible}</strong>, operadas sob a jurisdição <strong>{currentCase.sphere}</strong>, natureza <strong>{currentCase.nature}</strong>. O escopo abrange o período compreendido entre <strong>{currentCase.period.start}</strong> e <strong>{currentCase.period.end}</strong>, focando na regularidade documental e rastreabilidade dos fluxos financeiros.</p>
                  </section>

                  <section className="space-y-6">
                    <h2 className="text-[11px] uppercase tracking-[0.4em] font-black text-gray-300 border-b-2 pb-2">II. EXAME E FUNDAMENTAÇÃO</h2>
                    <p className="text-sm font-medium leading-[1.8]">A auditoria foi conduzida através do cruzamento analítico de extratos bancários institucionais com a prestação de contas doméstica apresentada. Foram aplicados os critérios de aceitabilidade fiscal e jurídica, conforme previsto nas normas do conselho de contabilidade e legislações aplicáveis ao caso concreto.</p>
                  </section>

                  <section className="space-y-8">
                    <h2 className="text-[11px] uppercase tracking-[0.4em] font-black text-gray-300 border-b-2 border-amber-500 pb-2 flex justify-between items-end">
                      III. DEMONSTRATIVO DE CAIXA PERICIAL
                      <span className="text-[8px] bg-amber-500 text-black px-2 py-0.5 rounded font-black tracking-widest">VALORES EM REAIS (R$)</span>
                    </h2>
                    <div className="bg-[#F8F9FA] p-12 rounded-2xl border-2 border-gray-100 space-y-6 font-mono text-xs shadow-inner">
                      <div className="flex justify-between border-b border-gray-200 pb-3">
                        <span className="text-gray-400 font-bold uppercase tracking-widest">(+) SALDO INICIAL</span>
                        <span className="font-bold">{formatCurrency(currentCase.initialBalance)}</span>
                      </div>
                      <div className="flex justify-between border-b border-gray-200 pb-3">
                        <span className="text-gray-400 font-bold uppercase tracking-widest">(+) RECEITAS VALIDADA</span>
                        <span className="font-bold text-green-600">{formatCurrency(currentCase.transactions.filter(t => t.type === 'INFLOW' && t.status === 'ACCEPTED').reduce((acc, t) => acc + t.value, 0))}</span>
                      </div>
                      <div className="flex justify-between border-b border-gray-200 pb-3">
                        <span className="text-gray-400 font-bold uppercase tracking-widest">(-) DESPESAS GLOSADAS</span>
                        <span className="font-bold text-red-500">({formatCurrency(currentCase.transactions.filter(t => t.status === 'GLOSSED').reduce((acc, t) => acc + t.value, 0))})</span>
                      </div>
                      <div className="flex justify-between border-b border-gray-200 pb-3">
                        <span className="text-gray-400 font-bold uppercase tracking-widest">(-) DESPESAS ACEITAS</span>
                        <span className="font-bold text-red-500">({formatCurrency(currentCase.transactions.filter(t => t.type === 'OUTFLOW' && t.status === 'ACCEPTED').reduce((acc, t) => acc + t.value, 0))})</span>
                      </div>
                      <div className="flex justify-between border-b-[6px] border-[#0A0C10] pb-4 font-bold text-2xl pt-10 text-[#0A0C10]">
                        <span className="font-serif italic capitalize tracking-tighter">(=) SALDO APURADO</span>
                        <span className="tracking-tighter">{formatCurrency(calculateSaldo(currentCase))}</span>
                      </div>
                    </div>
                  </section>

                  <section className="space-y-8">
                    <h2 className="text-[11px] uppercase tracking-[0.4em] font-black text-gray-300 border-b-2 pb-2">IV. CONCLUSÃO DO PERITO</h2>
                    <div className={cn(
                      "p-10 rounded-2xl border-2 font-bold shadow-sm relative overflow-hidden",
                      currentCase.transactions.some(t => t.status === 'GLOSSED') 
                        ? "bg-red-50/50 border-red-500/20 text-red-900" 
                        : "bg-green-50/50 border-green-500/20 text-green-900"
                    )}>
                      {currentCase.transactions.some(t => t.status === 'GLOSSED') && <div className="absolute top-4 right-4 bg-red-500 text-white px-3 py-1 rounded text-[8px] font-black tracking-widest">Ressalva Crítica</div>}
                      <p className="text-sm leading-[1.8]">Diante dos fatos expostos e documentação apreciada, este perito conclui pela 
                        <span className="underline decoration-2 underline-offset-4 mx-1.5 uppercase tracking-widest">
                          {currentCase.transactions.some(t => t.status === 'GLOSSED') ? 'IRREGULARIDADE CONTA' : 'REGULARIDADE CONTA'}
                        </span>. O saldo apurado de <span className="font-mono text-base ml-1">{formatCurrency(calculateSaldo(currentCase))}</span> demonstra a real situação patrimonial do encargo no período.</p>
                    </div>
                  </section>
                </div>

                <div className="mt-auto pt-24 pb-10 flex flex-col items-center gap-4">
                  <div className="w-16 h-1 bg-[#0A0C10]"></div>
                  <div className="text-center">
                    <p className="text-[11px] font-black uppercase tracking-[0.3em]">Perito Contador Vinícius Pinheiro</p>
                    <p className="text-[9px] text-gray-400 font-mono italic font-bold uppercase tracking-widest mt-1">Selo de Autenticidade Digital: 2024_PER_CONAT_X9</p>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Footer Design HTML Style */}
        <footer className="h-10 bg-[#0F1117] border-t border-white/5 px-10 flex items-center justify-between text-[10px] text-white/20 uppercase tracking-[0.2em] font-bold">
          <div className="flex gap-6 items-center">
            <span className="flex items-center gap-2"><div className="w-1 h-1 rounded-full bg-green-500" /> Database: 2024_04_PERITIA</span>
            <div className="h-3 w-px bg-white/5" />
            <span className="text-amber-500/40">Status: Conexão Segura</span>
          </div>
          <div className="font-mono text-[9px] tracking-tight">Copyright © 2024 ForensicSkill • Prestação de Contas V2.4</div>
        </footer>
      </main>
    </div>
  );
}

// Components
function SphereItem({ icon, label, active, onClick }: { icon: React.ReactNode, label: string, active: boolean, onClick: () => void }) {
  return (
    <button 
      onClick={onClick}
      className={cn(
        "w-full flex items-center gap-4 px-4 py-3 rounded-xl transition-all group border",
        active 
          ? "bg-amber-500 border-amber-500 text-black shadow-lg shadow-amber-500/20" 
          : "bg-[#161920]/40 border-white/5 text-white/40 hover:bg-white/5 hover:text-white"
      )}
    >
      <span className={cn(active ? "text-black" : "text-white/20 group-hover:text-white/40")}>{icon}</span>
      <span className="text-[11px] font-black uppercase tracking-widest">{label}</span>
      {active && <ChevronRight className="w-3 h-3 ml-auto" />}
    </button>
  );
}

function TabButton({ active, onClick, icon, label }: { active: boolean, onClick: () => void, icon: React.ReactNode, label: string }) {
  return (
    <button 
      onClick={onClick}
      className={cn(
        "flex items-center gap-3 px-6 py-2.5 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all",
        active ? "bg-amber-500 text-black shadow-lg shadow-amber-500/10" : "text-white/30 hover:text-white/60 hover:bg-white/5"
      )}
    >
      {icon}
      <span>{label}</span>
    </button>
  );
}

function StatCard({ label, value, icon, trend, variant }: { label: string, value: string, icon: React.ReactNode, trend?: string, variant?: 'danger'|'highlight' }) {
  return (
    <div className={cn(
      "p-6 rounded-2xl border transition-all hover:bg-white/5 relative overflow-hidden group",
      variant === 'highlight' ? "bg-amber-500/10 border-amber-500/20" : 
      variant === 'danger' ? "bg-red-500/5 border-red-500/10" : "bg-[#161920] border-white/5"
    )}>
      {variant === 'highlight' && <div className="absolute top-0 right-0 w-16 h-16 bg-amber-500/5 blur-2xl group-hover:bg-amber-500/10 transition-all" />}
      <div className="flex items-center justify-between mb-6">
        <span className={cn(
          "text-[10px] uppercase font-black tracking-[0.2em]", 
          variant === 'highlight' ? "text-amber-500" : 
          variant === 'danger' ? "text-red-500/60" : "text-white/20"
        )}>{label}</span>
        <div className="opacity-40 group-hover:opacity-100 transition-all">{icon}</div>
      </div>
      <div className={cn(
        "text-2xl font-black font-mono tracking-tighter",
        variant === 'highlight' ? "text-amber-500" : 
        variant === 'danger' ? "text-red-400" : "text-white"
      )}>{value}</div>
      {trend && <div className="mt-3 text-[9px] font-black uppercase tracking-widest opacity-20 group-hover:opacity-40 transition-all">{trend}</div>}
    </div>
  );
}

function StatusBadge({ status }: { status: Transaction['status'] }) {
  const configs = {
    ACCEPTED: { bg: 'bg-green-500/10 text-green-500 border-green-500/20', icon: <CheckCircle2 className="w-3 h-3" />, label: 'Validado' },
    GLOSSED: { bg: 'bg-red-500/10 text-red-500 border-red-500/20', icon: <AlertCircle className="w-3 h-3" />, label: 'Glosa' },
    PENDING: { bg: 'bg-amber-500/10 text-amber-500 border-amber-500/20', icon: <Clock className="w-3 h-3" />, label: 'Diligência' }
  };

  const config = configs[status];

  return (
    <div className={cn("flex items-center gap-2 px-3 py-1 rounded border text-[9px] font-black uppercase w-fit tracking-widest", config.bg)}>
      {config.icon}
      {config.label}
    </div>
  );
}

function ReconItem({ label, value, color = "text-white/80" }: { label: string, value: number, color?: string }) {
  return (
    <div className="flex items-center justify-between p-5 bg-[#0F1117] rounded-xl border border-white/5 hover:border-white/10 transition-all">
      <span className="text-[10px] uppercase tracking-widest font-black text-white/30">{label}</span>
      <span className={cn("font-mono font-black tracking-tighter text-sm", color)}>{formatCurrency(value)}</span>
    </div>
  );
}

function BulkActionItem({ onClick, icon, label, variant = 'primary' }: { onClick: () => void, icon: React.ReactNode, label: string, variant?: 'primary' | 'secondary' }) {
  return (
    <button 
      onClick={onClick}
      className={cn(
        "w-full flex items-center gap-3 px-4 py-3 rounded-lg text-[10px] font-bold uppercase tracking-widest transition-all text-left",
        variant === 'primary' ? "text-white/60 hover:bg-white/5 hover:text-white" : "text-white/30 hover:bg-red-500/10 hover:text-red-400"
      )}
    >
      {icon}
      {label}
    </button>
  );
}

// Helpers
function getPhaseStatus(stepPhase: string, currentPhase: string): 'active'|'completed'|'pending' {
  const phases: string[] = WORKFLOW_STEPS.map(s => s.id);
  const currentIdx = phases.indexOf(currentPhase);
  const stepIdx = phases.indexOf(stepPhase);
  if (stepIdx === currentIdx) return 'active';
  if (stepIdx < currentIdx) return 'completed';
  return 'pending';
}

function calculateSaldo(c: Case) {
  const inflows = c.transactions.filter(t => t.type === 'INFLOW' && t.status === 'ACCEPTED').reduce((acc, t) => acc + t.value, 0);
  const outflows = c.transactions.filter(t => t.type === 'OUTFLOW' && t.status === 'ACCEPTED').reduce((acc, t) => acc + t.value, 0);
  return c.initialBalance + inflows - outflows;
}

function prepareBarChartData(c: Case) {
  const inflows = c.transactions.filter(t => t.type === 'INFLOW' && t.status === 'ACCEPTED').reduce((acc, t) => acc + t.value, 0);
  const outflows = c.transactions.filter(t => t.type === 'OUTFLOW' && t.status === 'ACCEPTED').reduce((acc, t) => acc + t.value, 0);
  const glosas = c.transactions.filter(t => t.status === 'GLOSSED').reduce((acc, t) => acc + t.value, 0);
  
  return [
    { name: 'Receitas', value: inflows, color: '#22C55E' },
    { name: 'Despesas', value: outflows, color: '#EF4444' },
    { name: 'Glosas', value: glosas, color: '#F59E0B' },
    { name: 'Saldo Liq.', value: calculateSaldo(c), color: '#F59E0B' }
  ];
}

function preparePieChartData(c: Case) {
  const accepted = c.transactions.filter(t => t.status === 'ACCEPTED').length;
  const glossed = c.transactions.filter(t => t.status === 'GLOSSED').length;
  const pending = c.transactions.filter(t => t.status === 'PENDING').length;

  return [
    { name: 'Aceitos', value: accepted, color: '#22C55E' },
    { name: 'Glosas', value: glossed, color: '#EF4444' },
    { name: 'Pendentes', value: pending, color: '#F59E0B' }
  ];
}
