/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export const LEGAL_BASES = {
  JUDICIAL: [
    { code: 'CPC Art. 550', title: 'Legitimidade', description: 'Direito de exigir ou dever de prestar contas.' },
    { code: 'CPC Art. 551', title: 'Exigir Contas', description: 'Procedimento bifásico de cognição e liquidação.' },
    { code: 'CPC Art. 553', title: 'Sentença', description: 'O saldo é título executivo judicial.' },
  ],
  ADMINISTRATIVE: [
    { code: 'CF Art. 70-75', title: 'Fiscalização', description: 'Controle externo pelo Tribunal de Contas.' },
    { code: 'IN TCU 84/2020', title: 'Tomada de Contas', description: 'Procedimento para dano ao erário ou omissão.' },
  ],
  PRIVATE: [
    { code: 'CC Art. 1.978', title: 'Inventário', description: 'Dever do inventariante prestar contas.' },
    { code: 'CC Art. 1.348', title: 'Condomínio', description: 'Dever do síndico prestar contas anualmente.' },
  ]
};

export const WORKFLOW_STEPS = [
  { id: 'PATRIMONY', label: 'Patrimônio', description: 'Reconstituição do acervo gerido' },
  { id: 'ANALYSIS', label: 'Análise', description: 'Exame documental despesa a despesa' },
  { id: 'RECONCILIATION', label: 'Conciliação', description: 'Confronto com extratos bancários' },
  { id: 'BALANCE', label: 'Apuração', description: 'Cálculo do saldo credor/devedor' },
  { id: 'MONETARY', label: 'Atualização', description: 'Correção pelo IPCA-E e Juros' }
];

export const INDICES = [
  { id: 'IPCA', label: 'IPCA-E', description: 'Índice Nacional de Preços ao Consumidor Amplo Especial' },
  { id: 'SELIC', label: 'SELIC', description: 'Taxa referencial do Sistema Especial de Liquidação e de Custódia' },
  { id: 'TJ', label: 'Índice TJ', description: 'Tabela Prática do Tribunal de Justiça' }
];

export const CATEGORY_REQUIREMENTS: Record<string, string[]> = {
  'Receita': ['Extrato Bancário', 'Recibo/Nota Fiscal'],
  'Manutenção': ['Nota Fiscal Eletrônica', 'Comprovante Escaneado', 'Orçamento Prévio'],
  'Jurídico': ['Cópia do Alvará', 'Honorários (Recibo)', 'Contrato de Prestação'],
  'Impostos': ['Guia de Recolhimento', 'Autenticação Bancária'],
  'Repasse': ['Termo de Convênio', 'Extrato de Conta Específica'],
  'Suprimentos': ['Nota Fiscal de Venda', 'Ordem de Compra', 'Recibo de Entrega'],
  'Custeio': ['Holerite/Recibo', 'Encargos Vinculados'],
  'DEFAULT': ['Documento Comprobatório', 'Extrato Banco']
};
