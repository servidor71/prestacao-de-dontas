/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type CaseSphere = 'JUDICIAL' | 'ADMINISTRATIVE' | 'PRIVATE';

export type CasePhase = 
  | 'PATRIMONY' 
  | 'ANALYSIS' 
  | 'RECONCILIATION' 
  | 'BALANCE' 
  | 'MONETARY';

export interface ChecklistItem {
  id: string;
  label: string;
  status: 'PENDING' | 'VALIDATED' | 'MISSING';
  required: boolean;
}

export interface Transaction {
  id: string;
  date: string;
  description: string;
  type: 'INFLOW' | 'OUTFLOW';
  value: number;
  category: string;
  status: 'ACCEPTED' | 'GLOSSED' | 'PENDING';
  glosaReason?: string;
  glosaNotes?: string;
  legalBasis?: string;
  peritialNotes?: string;
  generalNotes?: string;
  hasDocument: boolean;
  documentRef?: string;
  checklist?: ChecklistItem[];
  isIllegible?: boolean;
  requiresDiligence?: boolean;
  diligenceDescription?: string;
  isAgreedDeduction?: boolean;
}

export interface Case {
  id: string;
  title: string;
  sphere: CaseSphere;
  nature: string; // e.g., Condomínio, Inventário, Convênio
  responsible: string;
  period: {
    start: string;
    end: string;
  };
  currentPhase: CasePhase;
  transactions: Transaction[];
  initialBalance: number;
  finalBalance: number;
  notes: string;
}

export interface MonetaryIndex {
  name: string;
  period: string;
  factor: number;
}
